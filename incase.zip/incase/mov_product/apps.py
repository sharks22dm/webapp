from django.apps import AppConfig


class MovProductConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mov_product'
